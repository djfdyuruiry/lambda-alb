"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const ts_lambda_api_1 = require("ts-lambda-api");
let HelloWorldController = 
// extending Controller is optional, it provides convience methods
class HelloWorldController extends ts_lambda_api_1.Controller {
    // GET, POST, PUT, PATCH and DELETE are supported
    get() {
        return {
            "hello": "world"
        };
    }
    // sub routes can be specifed in method decorators
    getSubResource() {
        return {
            "hello": "world",
            "from": "sub-resource"
        };
    }
    echoParameters(name, region) {
        return {
            name,
            region
        };
    }
    echoBody(body) {
        return body;
    }
    echoBinaryBody(contentType) {
        this.response
            .header("content-type", contentType)
            .sendFile(Buffer.from(this.request.rawBody, 'base64'));
    }
};
__decorate([
    ts_lambda_api_1.GET(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], HelloWorldController.prototype, "get", null);
__decorate([
    ts_lambda_api_1.GET("/sub-resource"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], HelloWorldController.prototype, "getSubResource", null);
__decorate([
    ts_lambda_api_1.GET("/echo-params"),
    __param(0, ts_lambda_api_1.queryParam("name")), __param(1, ts_lambda_api_1.header("region")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], HelloWorldController.prototype, "echoParameters", null);
__decorate([
    ts_lambda_api_1.POST("/echo-body"),
    ts_lambda_api_1.consumes("text/plain"),
    ts_lambda_api_1.produces("text/plain"),
    ts_lambda_api_1.apiRequest({ type: "string" }),
    ts_lambda_api_1.apiResponse(200, { type: "string" }),
    __param(0, ts_lambda_api_1.fromBody),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], HelloWorldController.prototype, "echoBody", null);
__decorate([
    ts_lambda_api_1.produces("application/octet-stream"),
    ts_lambda_api_1.POST("/echo-binary-body"),
    __param(0, ts_lambda_api_1.header("content-type")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], HelloWorldController.prototype, "echoBinaryBody", null);
HelloWorldController = __decorate([
    inversify_1.injectable() // all controller classes must be decorated with injectable
    ,
    ts_lambda_api_1.apiController("/hello-world")
    // extending Controller is optional, it provides convience methods
], HelloWorldController);
exports.HelloWorldController = HelloWorldController;
