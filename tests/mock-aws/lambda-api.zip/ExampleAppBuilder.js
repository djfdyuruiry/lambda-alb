"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = require("path");
const ts_lambda_api_1 = require("ts-lambda-api");
class ExampleAppBuilder {
    static build(apiAppBuilder) {
        let appConfig = new ts_lambda_api_1.AppConfig();
        appConfig.base = "/api/v1";
        appConfig.version = "v1";
        appConfig.openApi.enabled = true;
        let controllersPath = path_1.join(__dirname, "controllers");
        return apiAppBuilder(controllersPath, appConfig);
    }
}
exports.ExampleAppBuilder = ExampleAppBuilder;
