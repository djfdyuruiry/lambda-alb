"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ts_lambda_api_local_1 = require("ts-lambda-api-local");
const ExampleAppBuilder_1 = require("./ExampleAppBuilder");
const app = ExampleAppBuilder_1.ExampleAppBuilder.build((c, a) => new ts_lambda_api_local_1.ApiConsoleApp(c, a));
app.runServer(process.argv);
