"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ts_lambda_api_1 = require("ts-lambda-api");
const ExampleAppBuilder_1 = require("./ExampleAppBuilder");
const app = ExampleAppBuilder_1.ExampleAppBuilder.build((c, a) => new ts_lambda_api_1.ApiLambdaApp(c, a));
async function handler(event, context) {
    return await app.run(event, context);
}
exports.handler = handler;
